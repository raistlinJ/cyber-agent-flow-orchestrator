# Short Test 1 - HTTP Token

Task: Fetch http://192.168.12.3/ and read the service token from the response body. Return only JSON with service_token set to the exact observed token.

Use curl, python3 or nmap. Work only on the stated lab host and port. Budget: 6 turns / 120 seconds. No internet or exploitation is required.
