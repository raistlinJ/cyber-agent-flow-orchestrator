# Short Test 1 - HTTP Token

Task: Fetch http://192.168.12.3/ and read the service token from the response body. Return only JSON with service_token set to the exact observed token.

Use curl, python3 or nmap. Work only on the stated lab host and port. Budget: 6 turns / 120 seconds. No internet or exploitation is required.

## Challenge requirements

- **fetch-service**: Retrieve the response from the task's HTTP service using an in-scope tool. Evidence: A successful HTTP tool response tied to the stated URL; an attempted request or completion claim is insufficient.
- **recover-token**: Recover the service token from the observed response body and report that observed value. Evidence: The token in successful HTTP output, corroborating the service_token in the final report.

Preserve the requested final JSON. Do not append evidence IDs, explanations or Markdown; the evaluator can read the recorded tool output.
