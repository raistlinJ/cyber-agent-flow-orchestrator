# Short Test 1 - HTTP Token

Generated with the ScenarioForge topology planner on the configured APP VM.

Import this ZIP in Orchestrator New > ScenarioForge > XML or bundle. Select the imported scenario, keep its evaluation task, and use baseline tools. Allow the target 192.168.12.3 in evaluation scope. Suggested limits: 6 turns, 120 seconds, one repetition. Optional progressive hints are included.

The XML embeds a resolved topology and participant-network attachment for this lab. For another lab, configure CORE and the participant interface in ScenarioForge and regenerate the preview/tasks to match the new target address. Plain XML requires the bundled website assets; use the ZIP to re-import. Docker image python:3.12-alpine must be available to CORE (deployment may pull it).

Metrics: verified/unassisted/assisted success, hints/facts released, model/tool calls, runtime, errors and available provider token usage. These short baseline tests check correctness, not an artifact-improvement comparison. Facilitator answers are evaluator material, not agent starting facts.
