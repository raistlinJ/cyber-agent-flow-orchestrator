# Short Test 1 - HTTP Token - facilitator

Expected answer: {"service_token": "CAF_TEST_HTTP_7d3a91"}

Solution paths: /

Hints: Fetch the starting URL with curl.
The token is the plain text response body.

These are deterministic test tokens, not secret production data.

## Evidence-based evaluation

The saved task uses **Both**: exact JSON correctness and evidence-based rubric
review. Enable Evaluation > Judge LLM before creating the experiment. For a quick
exact-only check, choose Edit loaded tasks and set verification to Exact checks.
The criterion score measures observed completion; an incorrect final JSON cannot
pass Both even when some criteria are satisfied. Missing evidence stays unverified.

Keep the required final JSON shape; do not append evidence fields or explanations.
The judge reads execution logs and cites observed HTTP responses. Private rubric
references and facilitator answers stay out of the participant briefing. Private
hints are released only when enabled for the trial. A solution is assisted success,
not independent discovery. Lab reset in New is on by default; it redeploys the
frozen scenario, not a whole VM snapshot. The target and saved topology are unchanged.

These are development scenarios. Do not divide the same scenario family across
held-out splits or treat repeated trials as independent scenarios. Baseline-only
runs establish functionality, not artifact improvement. Add an explicit helper or
guidance condition to measure improvement. Judge accuracy is not human calibrated.

Current metadata was checked using native import/export and host scoring tests.
Historical live-VM passes apply to the earlier checksums in
validation-2026-10-02-original.json; new live-VM/LLM validation is still pending.

### Private rubric

```json
{
  "version": 1,
  "criteria": [
    {
      "id": "fetch-service",
      "requirement": "Retrieve the response from the task's HTTP service using an in-scope tool.",
      "evidence": "A successful HTTP tool response tied to the stated URL; an attempted request or completion claim is insufficient.",
      "essential": true,
      "weight": 1
    },
    {
      "id": "recover-token",
      "requirement": "Recover the service token from the observed response body and report that observed value.",
      "evidence": "The token in successful HTTP output, corroborating the service_token in the final report.",
      "essential": true,
      "weight": 1,
      "private_reference": "Expected service_token: CAF_TEST_HTTP_7d3a91"
    }
  ]
}
```
