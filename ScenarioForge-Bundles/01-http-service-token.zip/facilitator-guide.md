# Short Test 1 - HTTP Token - facilitator

Expected answer: {"service_token": "CAF_TEST_HTTP_7d3a91"}

Solution paths: /

Hints: Fetch the starting URL with curl.
The token is the plain text response body.

These are deterministic test tokens, not secret production data.
