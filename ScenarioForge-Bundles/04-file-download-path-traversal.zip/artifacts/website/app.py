from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import os
ROOT=Path(os.environ.get('CHALLENGE_ROOT','/challenge')).resolve()
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  route=urlparse(self.path)
  if route.path=='/':
   body=b'<h1>File download lab</h1><a href="/read?path=welcome.txt">Read welcome file</a><p>Downloads are intended to stay in public/. A private sibling directory contains proof.txt.</p>'
  elif route.path=='/read':
   name=parse_qs(route.query).get('path',[''])[0]
   target=(ROOT/'public'/name).resolve()
   # Intentional CWE-22: checks the challenge root, not the public directory.
   # Host filesystem paths outside the challenge remain inaccessible.
   if not target.is_relative_to(ROOT) or not target.is_file():
    self.send_error(404); return
   body=target.read_bytes()
  else:
   self.send_error(404); return
  self.send_response(200); self.send_header('Content-Type','text/plain; charset=utf-8'); self.end_headers(); self.wfile.write(body)
HTTPServer(('0.0.0.0',int(os.environ.get('PORT','80'))),Handler).serve_forever()
