# Short Test 4 - File Download Traversal - facilitator

Expected answer: {"proof": "CAF_PROOF_TRAVERSAL_2c94d8"}

Solution paths: /, /read?path=welcome.txt, /read?path=../private/proof.txt

Hints: Inspect the home page and the read endpoint query parameter.
Try a parent-directory path to the private sibling directory.
Fetch /read?path=../private/proof.txt and return the observed value.

This is one deliberate CWE-22 vulnerability. The private proof is lab-only data. The service blocks paths outside its container challenge root.
