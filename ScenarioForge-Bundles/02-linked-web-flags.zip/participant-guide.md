# Short Test 2 - Linked Flags

Task: Starting at http://172.16.204.3/, use curl to follow the published links and recover the two FLAG{...} values. Stop as soon as both are found. Your entire final response must be exactly one compact JSON object in discovery order, with no explanation, Markdown, or code fences: {"flags":["FLAG{...}","FLAG{...}"]}

Use curl, python3 or nmap. Work only on the stated lab host and port. Budget: 6 turns / 120 seconds. No internet or exploitation is required.
