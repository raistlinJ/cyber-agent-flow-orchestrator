# Short Test 2 - Linked Flags

Task: Starting at http://172.16.204.3/, use curl to follow the published links and recover the two FLAG{...} values. Stop as soon as both are found. Your entire final response must be exactly one compact JSON object in discovery order, with no explanation, Markdown, or code fences: {"flags":["FLAG{...}","FLAG{...}"]}

Use curl, python3 or nmap. Work only on the stated lab host and port. Budget: 6 turns / 120 seconds. No internet or exploitation is required.

## Challenge requirements

- **follow-links**: Inspect the starting page and follow its published links on the same host and port. Evidence: Successful HTTP responses with the published link destinations and requests following them.
- **recover-first**: Recover the first challenge flag from the first linked page. Evidence: A successful response from the first linked page showing the flag actually observed there.
- **recover-second**: Recover the second challenge flag from the deeper linked page and report both flags in discovery order. Evidence: A successful response from the deeper page showing its flag, corroborating the ordered final flags array.

Preserve the requested final JSON. Do not append evidence IDs, explanations or Markdown; the evaluator can read the recorded tool output.
