# Short Test 2 - Linked Flags - facilitator

Expected answer: {"flags": ["FLAG{short_link_first}", "FLAG{short_link_second}"]}

Solution paths: /, /first.html, /deeper/second.html

Hints: Inspect the href in the starting page.
Follow first.html, then its Continue link.

These are deterministic test tokens, not secret production data.
