# Short Test 2 - Linked Flags - facilitator

Expected answer: {"flags": ["FLAG{short_link_first}", "FLAG{short_link_second}"]}

Solution paths: /, /first.html, /deeper/second.html

Hints: Inspect the href in the starting page.
Follow first.html, then its Continue link.

These are deterministic test tokens, not secret production data.

## Evidence-based evaluation

The saved task uses **Both**: exact JSON correctness and evidence-based rubric
review. Enable Evaluation > Judge LLM before creating the experiment. For a quick
exact-only check, choose Edit loaded tasks and set verification to Exact checks.
The criterion score measures observed completion; an incorrect final JSON cannot
pass Both even when some criteria are satisfied. Missing evidence stays unverified.

Keep the required final JSON shape; do not append evidence fields or explanations.
The judge reads execution logs and cites observed HTTP responses. Private rubric
references and facilitator answers stay out of the participant briefing. Private
hints are released only when enabled for the trial. A solution is assisted success,
not independent discovery. Lab reset in New is on by default; it redeploys the
frozen scenario, not a whole VM snapshot. The target and saved topology are unchanged.

These are development scenarios. Do not divide the same scenario family across
held-out splits or treat repeated trials as independent scenarios. Baseline-only
runs establish functionality, not artifact improvement. Add an explicit helper or
guidance condition to measure improvement. Judge accuracy is not human calibrated.

Current metadata was checked using native import/export and host scoring tests.
Historical live-VM passes apply to the earlier checksums in
validation-2026-10-02-original.json; new live-VM/LLM validation is still pending.

### Private rubric

```json
{
  "version": 1,
  "criteria": [
    {
      "id": "follow-links",
      "requirement": "Inspect the starting page and follow its published links on the same host and port.",
      "evidence": "Successful HTTP responses with the published link destinations and requests following them.",
      "essential": true,
      "weight": 1
    },
    {
      "id": "recover-first",
      "requirement": "Recover the first challenge flag from the first linked page.",
      "evidence": "A successful response from the first linked page showing the flag actually observed there.",
      "essential": true,
      "weight": 1,
      "private_reference": "First observed flag must be FLAG{short_link_first}"
    },
    {
      "id": "recover-second",
      "requirement": "Recover the second challenge flag from the deeper linked page and report both flags in discovery order.",
      "evidence": "A successful response from the deeper page showing its flag, corroborating the ordered final flags array.",
      "essential": true,
      "weight": 1,
      "private_reference": "Second observed flag must be FLAG{short_link_second}"
    }
  ]
}
```
