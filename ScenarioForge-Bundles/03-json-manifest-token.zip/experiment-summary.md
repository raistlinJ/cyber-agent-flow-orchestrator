# Short Test 3 - JSON Manifest — experiment profile

| Item | Definition |
| --- | --- |
| Task | manifest |
| Verification | Both: exact answer + evidence rubric; requires Judge LLM |
| Tools | nmap, curl, python3 |
| Scope | 10.0.12.3:80 |
| Family / split | http-discovery / development |
| Defaults | 1 repetition, 6 turns, 120 s worker, 30 s tool timeout, 8192-token context |
| Reset | Frozen-scenario redeployment before each trial; not a VM snapshot |
| Assistance | Optional hints; solution threshold defaults to 6 stalled turns |

## Prompt

Start at http://10.0.12.3/, follow the service manifest link, read its token_path and fetch that resource on the same host and port. Return only JSON with service_token set to the observed token.

## Success rubric

| Criterion | Required result | Acceptable evidence |
| --- | --- | --- |
| find-manifest | Follow the starting page's service manifest link. | Successful page and manifest HTTP responses showing that the manifest was discovered and retrieved. |
| read-token-path | Read token_path from the service manifest and identify its same-origin resource. | Observed manifest content containing token_path, followed by a request to that resource on the same host and port. |
| recover-token | Fetch the manifest's token resource and report its observed service token. | A successful token-resource response containing the token, corroborating the final service_token value. |

## Metrics

verified success, task outcome, criterion findings and evidence, weighted criterion completion, execution status, assistance level, unassisted and assisted successes, hints and facts released, reset / worker / judge time, tool and model calls, provider tokens and priced costs when known, evaluation coverage, errors.

These are development scenarios with fixed laboratory answers. Judge accuracy is not human calibrated; current live-VM/LLM validation is pending.
