# Short Test 3 - JSON Manifest

Task: Start at http://10.0.12.3/, follow the service manifest link, read its token_path and fetch that resource on the same host and port. Return only JSON with service_token set to the observed token.

Use curl, python3 or nmap. Work only on the stated lab host and port. Budget: 6 turns / 120 seconds. No internet or exploitation is required.

## Challenge requirements

- **find-manifest**: Follow the starting page's service manifest link. Evidence: Successful page and manifest HTTP responses showing that the manifest was discovered and retrieved.
- **read-token-path**: Read token_path from the service manifest and identify its same-origin resource. Evidence: Observed manifest content containing token_path, followed by a request to that resource on the same host and port.
- **recover-token**: Fetch the manifest's token resource and report its observed service token. Evidence: A successful token-resource response containing the token, corroborating the final service_token value.

Preserve the requested final JSON. Do not append evidence IDs, explanations or Markdown; the evaluator can read the recorded tool output.
