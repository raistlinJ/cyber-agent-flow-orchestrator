# Short Test 3 - JSON Manifest

Task: Start at http://10.0.12.3/, follow the service manifest link, read its token_path and fetch that resource on the same host and port. Return only JSON with service_token set to the observed token.

Use curl, python3 or nmap. Work only on the stated lab host and port. Budget: 6 turns / 120 seconds. No internet or exploitation is required.
