# Short Test 3 - JSON Manifest

Generated with the ScenarioForge topology planner on the configured APP VM.

Import this ZIP in Orchestrator New > ScenarioForge > XML or bundle. Select the imported scenario, keep its evaluation task, and use baseline tools. Allow the target 10.0.12.3 in evaluation scope. Suggested limits: 6 turns, 120 seconds, one repetition. Optional progressive hints are included.

The XML embeds a resolved topology and participant-network attachment for this lab. For another lab, configure CORE and the participant interface in ScenarioForge and regenerate the preview/tasks to match the new target address. Plain XML requires the bundled website assets; use the ZIP to re-import. Docker image python:3.12-alpine must be available to CORE (deployment may pull it).

Metrics: verified/unassisted/assisted success, hints/facts released, model/tool calls, runtime, errors and available provider token usage. These short baseline tests check correctness, not an artifact-improvement comparison. Facilitator answers are evaluator material, not agent starting facts.

## Evidence-based evaluation

The saved task uses **Both**: exact JSON correctness and evidence-based rubric
review. Enable Evaluation > Judge LLM before creating the experiment. For a quick
exact-only check, choose Edit loaded tasks and set verification to Exact checks.
The criterion score measures observed completion; an incorrect final JSON cannot
pass Both even when some criteria are satisfied. Missing evidence stays unverified.

Keep the required final JSON shape; do not append evidence fields or explanations.
The judge reads execution logs and cites observed HTTP responses. Private rubric
references and facilitator answers stay out of the participant briefing. Private
hints are released only when enabled for the trial. A solution is assisted success,
not independent discovery. Lab reset in New is on by default; it redeploys the
frozen scenario, not a whole VM snapshot. The target and saved topology are unchanged.

These are development scenarios. Do not divide the same scenario family across
held-out splits or treat repeated trials as independent scenarios. Baseline-only
runs establish functionality, not artifact improvement. Add an explicit helper or
guidance condition to measure improvement. Judge accuracy is not human calibrated.

Current metadata was checked using native import/export and host scoring tests.
Historical live-VM passes apply to the earlier checksums in
validation-2026-10-02-original.json; new live-VM/LLM validation is still pending.
