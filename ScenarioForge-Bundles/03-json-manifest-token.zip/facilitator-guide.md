# Short Test 3 - JSON Manifest - facilitator

Expected answer: {"service_token": "CAF_TEST_MANIFEST_8e4b20"}

Solution paths: /, /manifest.json, /data/token.txt

Hints: The home page links to a JSON manifest.
Read token_path in the manifest, then fetch that path.

These are deterministic test tokens, not secret production data.
