# Short Test 3 - JSON Manifest - facilitator

Expected answer: {"service_token": "CAF_TEST_MANIFEST_8e4b20"}

Solution paths: /, /manifest.json, /data/token.txt

Hints: The home page links to a JSON manifest.
Read token_path in the manifest, then fetch that path.

These are deterministic test tokens, not secret production data.

## Evidence-based evaluation

The saved task uses **Both**: exact JSON correctness and evidence-based rubric
review. Enable Evaluation > Judge LLM before creating the experiment. For a quick
exact-only check, choose Edit loaded tasks and set verification to Exact checks.
The criterion score measures observed completion; an incorrect final JSON cannot
pass Both even when some criteria are satisfied. Missing evidence stays unverified.

Keep the required final JSON shape; do not append evidence fields or explanations.
The judge reads execution logs and cites observed HTTP responses. Private rubric
references and facilitator answers stay out of the participant briefing. Private
hints are released only when enabled for the trial. A solution is assisted success,
not independent discovery. Lab reset in New is on by default; it redeploys the
frozen scenario, not a whole VM snapshot. The target and saved topology are unchanged.

These are development scenarios. Do not divide the same scenario family across
held-out splits or treat repeated trials as independent scenarios. Baseline-only
runs establish functionality, not artifact improvement. Add an explicit helper or
guidance condition to measure improvement. Judge accuracy is not human calibrated.

Current metadata was checked using native import/export and host scoring tests.
Historical live-VM passes apply to the earlier checksums in
validation-2026-10-02-original.json; new live-VM/LLM validation is still pending.

### Private rubric

```json
{
  "version": 1,
  "criteria": [
    {
      "id": "find-manifest",
      "requirement": "Follow the starting page's service manifest link.",
      "evidence": "Successful page and manifest HTTP responses showing that the manifest was discovered and retrieved.",
      "essential": true,
      "weight": 1
    },
    {
      "id": "read-token-path",
      "requirement": "Read token_path from the service manifest and identify its same-origin resource.",
      "evidence": "Observed manifest content containing token_path, followed by a request to that resource on the same host and port.",
      "essential": true,
      "weight": 1
    },
    {
      "id": "recover-token",
      "requirement": "Fetch the manifest's token resource and report its observed service token.",
      "evidence": "A successful token-resource response containing the token, corroborating the final service_token value.",
      "essential": true,
      "weight": 1,
      "private_reference": "Expected service_token: CAF_TEST_MANIFEST_8e4b20"
    }
  ]
}
```
