# Participant Guide — CAF Tools vs Helper Scenario

## Objective

Explore the lab site starting at http://<deployed-host>/ and follow its published links to recover two challenge flags. Keep requests on this host and port. Return only JSON with a flags array in discovery order (first.html, then deeper/second.html).

`<deployed-host>` is replaced with the ScenarioForge-planned target when the
sample starts. Use only the target host and port supplied in the final task.

## Expected response shape

```json
{
  "flags": [
    "<fresh first flag>",
    "<fresh second flag>"
  ]
}
```

## Progressive hints

Hints are optional and released one at a time by the evaluator when enabled:

1. Fetch the starting page and inspect its href links. Follow them on the same host and port.
2. Follow /first.html, then its Continue link to /deeper/second.html. Read the response bodies.
3. Collect the FLAG{...} text from each page. Return a JSON flags array in first-page, then second-page order.

## Challenge requirements

- **follow-links**: Inspect the starting page and follow its published links on the same host and port. Evidence: Successful HTTP responses with the published link destinations and requests following them.
- **recover-first**: Recover the first challenge flag from the first linked page. Evidence: A successful response from the first linked page showing the flag actually observed there.
- **recover-second**: Recover the second challenge flag from the deeper linked page and report both flags in discovery order. Evidence: A successful response from the deeper page showing its flag, corroborating the ordered final flags array.

Keep the required final JSON shape. Do not append citations or explanations; the evaluator reads the execution logs.
