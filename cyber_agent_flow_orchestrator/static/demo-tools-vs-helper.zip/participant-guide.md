# Participant Guide — CAF Tools vs Helper Scenario

## Objective

Explore the lab site starting at http://<deployed-host>/ and follow its published links to recover two challenge flags. Keep requests on this host and port. Return only JSON with a flags array in discovery order (first.html, then deeper/second.html).

`<deployed-host>` is replaced with the ScenarioForge-planned target when the
sample starts. Use only the target host and port supplied in the final task.

## Expected response shape

```json
{
  "flags": [
    "<fresh first flag>",
    "<fresh second flag>"
  ]
}
```

## Progressive hints

Hints are optional and released one at a time by the evaluator when enabled:

1. Fetch the starting page and inspect its href links. Follow them on the same host and port.
2. Follow /first.html, then its Continue link to /deeper/second.html. Read the response bodies.
3. Collect the FLAG{...} text from each page. Return a JSON flags array in first-page, then second-page order.
