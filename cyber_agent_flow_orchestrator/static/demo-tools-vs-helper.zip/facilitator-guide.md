# Facilitator Guide — CAF Tools vs Helper Scenario

## Evaluation task

- Task ID: `tools-vs-helper`
- Family: `http-discovery`
- Prompt source: `evaluation-task-template.json`
- Verification: exact JSON equality against fresh run-time values
- Required readiness checks: `containers`, `services`, `ports`
- Progressive hints: optional; three ordered hints

ScenarioForge resolves the website node and address. The orchestrator then
generates fresh expected values, updates the website, writes the exact prompt and
private verifier into `FlowState.evaluation_tasks`, and captures them in Results.
The static bundle intentionally contains no run-time answer.

## Hint sequence

1. Fetch the starting page and inspect its href links. Follow them on the same host and port.
2. Follow /first.html, then its Continue link to /deeper/second.html. Read the response bodies.
3. Collect the FLAG{...} text from each page. Return a JSON flags array in first-page, then second-page order.
