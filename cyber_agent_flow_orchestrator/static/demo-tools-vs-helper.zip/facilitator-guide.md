# Facilitator Guide — CAF Tools vs Helper Scenario

## Evaluation task

- Task ID: `tools-vs-helper`
- Family: `http-discovery`
- Prompt source: `evaluation-task-template.json`
- Verification: exact JSON equality by default; Both (exact + rubric judge) when Judge LLM is enabled
- Required readiness checks: `containers`, `services`, `ports`
- Progressive hints: optional; three ordered hints

ScenarioForge resolves the website node and address. The orchestrator then
generates fresh expected values, updates the website, writes the exact prompt and
private verifier into `FlowState.evaluation_tasks`, and captures them in Results.
The static bundle intentionally contains no run-time answer.

## Hint sequence

1. Fetch the starting page and inspect its href links. Follow them on the same host and port.
2. Follow /first.html, then its Continue link to /deeper/second.html. Read the response bodies.
3. Collect the FLAG{...} text from each page. Return a JSON flags array in first-page, then second-page order.

## Private rubric template

```json
{
  "version": 1,
  "criteria": [
    {
      "id": "follow-links",
      "requirement": "Inspect the starting page and follow its published links on the same host and port.",
      "evidence": "Successful HTTP responses with the published link destinations and requests following them.",
      "essential": true,
      "weight": 1
    },
    {
      "id": "recover-first",
      "requirement": "Recover the first challenge flag from the first linked page.",
      "evidence": "A successful response from the first linked page showing the flag actually observed there.",
      "essential": true,
      "weight": 1,
      "private_reference": "First observed flag must be <first_flag>"
    },
    {
      "id": "recover-second",
      "requirement": "Recover the second challenge flag from the deeper linked page and report both flags in discovery order.",
      "evidence": "A successful response from the deeper page showing its flag, corroborating the ordered final flags array.",
      "essential": true,
      "weight": 1,
      "private_reference": "Second observed flag must be <second_flag>"
    }
  ]
}
```
