# CAF Model Smoke Scenario

Import this reproduction ZIP with Orchestrator New → ScenarioForge XML or bundle,
or use ScenarioForge's scenario import. The ZIP contains the XML, a read-only
HTTP website, Docker Compose definition, original sample tool catalogs, and
demo-profile.json. Plain XML alone requires these payloads to be available.

The New experiment sample preset automatically prepares this fixed XML using the
ScenarioForge CORE connection, resolves a deterministic topology, generates fresh
service tokens/flags, deploys the website, checks readiness, and evaluates CAF.
Select ScenarioForge, participant, and CoreVM roles before creating the sample.
The participant must be able to route to the generated CORE lab host.

The smoke sample uses baseline tools to fetch a fresh service token. The helper
sample uses three paired repetitions with baseline tools and the added HTTP helper.
The host address is resolved from ScenarioForge's actual preview, not hardcoded.
Importing this ZIP as a generic custom scenario does not select the sample preset;
use the named sample to apply its fixed preparation and evaluation configuration.

Docker image: python:3.12-alpine (must be available to the CORE deployment).
Expected HTTP port: 80. Bundle source: /tmp/vulns/flag_node_generators_runs/caf-demo-smoke.

Task metadata is available at the bundle root in evaluation-task-template.json.
It is a template rather than a runnable evaluation-tasks.json because the final
target address and expected token/flags are generated after ScenarioForge plans
and deploys the sample. The orchestrator turns it into the exact task definition
stored in the run results and bundle.

## Evidence-based evaluation

This bundle includes a version 1 challenge rubric. Exact checks run by default;
enabling Evaluation > Judge LLM selects Both (correct JSON plus observed execution
evidence). The host computes criterion completion and success/partial/fail/unverified
outcomes. Preserve the required final JSON; execution logs supply evidence.
Private hints are always exported, but are released only when enabled for a trial.
Trial budgets and model settings are editable. Lab resets are enabled by default
in New; resets redeploy the scenario, not a whole VM snapshot.

The HTTP helper is hand-authored. This demo tests adding that particular tool,
not whether automatically generated artifacts improve performance. The demos are
development checks, not held-out scenarios or human-calibrated judge evaluations.
