# Facilitator Guide — CAF Model Smoke Scenario

## Evaluation task

- Task ID: `smoke`
- Family: `http-discovery`
- Prompt source: `evaluation-task-template.json`
- Verification: exact JSON equality by default; Both (exact + rubric judge) when Judge LLM is enabled
- Required readiness checks: `containers`, `services`, `ports`
- Progressive hints: optional; three ordered hints

ScenarioForge resolves the website node and address. The orchestrator then
generates fresh expected values, updates the website, writes the exact prompt and
private verifier into `FlowState.evaluation_tasks`, and captures them in Results.
The static bundle intentionally contains no run-time answer.

## Hint sequence

1. Use the curl tool to fetch the HTTP address in the task; inspect the response body.
2. The service token is plain text in the response body, not in a header. Remove the trailing newline.
3. Return a JSON object with the single key service_token and the exact token you observed; omit Markdown.

## Private rubric template

```json
{
  "version": 1,
  "criteria": [
    {
      "id": "fetch-service",
      "requirement": "Retrieve the response from the task's HTTP service using an in-scope tool.",
      "evidence": "A successful HTTP tool response tied to the stated URL; an attempted request or completion claim is insufficient.",
      "essential": true,
      "weight": 1
    },
    {
      "id": "recover-token",
      "requirement": "Recover the service token from the observed response body and report that observed value.",
      "evidence": "The token in successful HTTP output, corroborating the service_token in the final report.",
      "essential": true,
      "weight": 1,
      "private_reference": "Expected service_token: <service_token>"
    }
  ]
}
```
