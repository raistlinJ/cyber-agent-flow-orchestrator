# Participant Guide — CAF Model Smoke Scenario

## Objective

Fetch http://<deployed-host>/ and read the service token from its response body. Return only JSON with service_token set to the exact observed token.

`<deployed-host>` is replaced with the ScenarioForge-planned target when the
sample starts. Use only the target host and port supplied in the final task.

## Expected response shape

```json
{
  "service_token": "<fresh token generated when the sample starts>"
}
```

## Progressive hints

Hints are optional and released one at a time by the evaluator when enabled:

1. Use the curl tool to fetch the HTTP address in the task; inspect the response body.
2. The service token is plain text in the response body, not in a header. Remove the trailing newline.
3. Return a JSON object with the single key service_token and the exact token you observed; omit Markdown.
